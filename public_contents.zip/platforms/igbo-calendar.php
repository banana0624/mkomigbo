<?php
declare(strict_types=1);

/**
 * project-root/public/platforms/igbo-calendar.php
 * Visualizer for the Igbo 13-month calendar.
 */

/* 1) Bootstrap (initialize.php) */
$init = dirname(__DIR__, 2) . '/private/assets/initialize.php';
if (!is_file($init)) {
  echo "<h1>FATAL: initialize.php missing</h1>";
  echo "<p>Expected at: {$init}</p>";
  exit;
}
require_once $init;

/* 2) Load Igbo calendar helpers */
$calendar_functions = dirname(__DIR__, 2) . '/private/functions/igbo_calendar_functions.php';
if (!is_file($calendar_functions)) {
  echo "<h1>FATAL: igbo_calendar_functions.php missing</h1>";
  echo "<p>Expected at: {$calendar_functions}</p>";
  exit;
}
require_once $calendar_functions;

/* 3) Safety: local h() if not already available */
if (!function_exists('h')) {
  function h(string $s = ''): string {
    return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
  }
}

/* 4) Define Igbo New Year start for this cycle.
 * NOTE: adjust this to the actual new moon of February for the year.
 * For now we use a placeholder around the 3rd week of February.
 */
$igboYearStart = new DateTimeImmutable('2025-02-20'); // example only
$yearLabel     = '2025/2026';

/* 5) Compute today's Igbo date */
$today     = new DateTimeImmutable('today');
$igboToday = igbo_from_gregorian($today, $igboYearStart, $yearLabel);

/* 6) Build the full year grid */
$igboYear      = igbo_year_grid($igboYearStart, $yearLabel);
$weekdayNames  = igbo_weekday_names();
$monthDefs     = igbo_month_definitions();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Igbo Calendar – <?= h($yearLabel) ?></title>

  <!-- PWA manifest + theme color -->
  <link rel="manifest" href="<?= h(url_for('/manifest-igbo-calendar.webmanifest')) ?>">
  <meta name="theme-color" content="#222222">

  <link rel="stylesheet" href="<?= h(url_for('/lib/css/subjects.css')) ?>">
  <style>
    .igbo-calendar-container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 1rem;
    }

    /* Summary table at the top */
    .igbo-summary {
      margin: 1rem 0 2rem;
      font-size: 0.9rem;
      border-collapse: collapse;
      width: 100%;
    }
    .igbo-summary th,
    .igbo-summary td {
      border: 1px solid #ddd;
      padding: 0.4rem;
      text-align: left;
    }
    .igbo-summary th {
      background: #f0f0f0;
    }
    .igbo-summary caption {
      text-align: left;
      font-weight: 600;
      margin-bottom: 0.3rem;
    }

    /* Month cards layout:
       - On wide screens: ~3 per row
       - On medium screens: 2 per row
       - On very small screens: 1 per row
    */
    .igbo-calendar-months {
      display: flex;
      flex-wrap: wrap;
      gap: 1rem;
    }
    .igbo-month {
      border: 1px solid #ccc;
      padding: 0.5rem;
      font-size: 0.85rem;
      background: #fafafa;
      flex: 1 1 calc(50% - 1rem);   /* default: 2 per row */
      max-width: calc(50% - 1rem);
    }
    @media (min-width: 1100px) {
      .igbo-month {
        flex: 1 1 calc(33.333% - 1rem);  /* 3 per row on large screens */
        max-width: calc(33.333% - 1rem);
      }
    }
    @media (max-width: 700px) {
      .igbo-month {
        flex: 1 1 100%;    /* single column on small screens */
        max-width: 100%;
      }
    }

    .igbo-month h2 {
      margin: 0;
      font-size: 1rem;
      text-align: center;
    }
    .igbo-month p.month-span {
      margin: 0.1rem 0 0.3rem;
      font-size: 0.75rem;
      text-align: center;
      color: #555;
    }

    .igbo-month table {
      width: 100%;
      border-collapse: collapse;
      table-layout: fixed;
    }
    .igbo-month th,
    .igbo-month td {
      border: 1px solid #ddd;
      padding: 0.25rem;
      text-align: center;
      vertical-align: top;
    }
    .igbo-month th {
      background: #eee;
      font-weight: 600;
    }

    .igbo-day-num {
      font-weight: 700;
      display: block;
      margin-bottom: 0.1rem;
    }
    .igbo-moon-symbol {
      display: block;
      font-size: 1.2rem;
      line-height: 1.2;
      margin-bottom: 0.1rem;
    }
    .igbo-lunar {
      display: block;
      font-size: 0.7rem;
      color: #555;
    }
    .igbo-greg {
      display: block;
      font-size: 0.7rem;
      color: #777;
    }
    .igbo-today {
      outline: 2px solid #0066cc;
      background: #e8f3ff;
    }

    .igbo-month-subtitle {
      text-align: center;
      font-size: 0.75rem;
      margin: 0 0 0.3rem;
      color: #555;
    }
  </style>
</head>
<body>
<div class="igbo-calendar-container">
  <h1>Igbo Calendar – <?= h($yearLabel) ?></h1>

  <?php if ($igboToday !== null): ?>
    <p>
      Today (Gregorian): <strong><?= h($today->format('Y-m-d')) ?></strong><br>
      Today (Igbo):
      <?php if ($igboToday['is_festival']): ?>
        <strong>Festival / intercalary day</strong>,
        weekday <?= h($igboToday['weekday_name']) ?>,
        day-of-year <?= (int)$igboToday['day_of_year'] ?>.
      <?php else: ?>
        Year <strong><?= h((string)($igboToday['year_label'] ?? '')) ?></strong>,
        Month <strong><?= (int)$igboToday['month'] ?></strong>,
        Day <strong><?= (int)$igboToday['day_in_month'] ?></strong>,
        <strong><?= h($igboToday['weekday_name']) ?></strong>,
        lunar stage: <strong><?= h($igboToday['lunar_stage']) ?></strong>.
      <?php endif; ?>
    </p>
  <?php else: ?>
    <p>This Gregorian date is before the start of this Igbo year.</p>
  <?php endif; ?>

  <!-- Top summary: linear view of months and their Gregorian spans -->
  <table class="igbo-summary">
    <caption>Overview of the Igbo Year (<?= h($yearLabel) ?>)</caption>
    <thead>
      <tr>
        <th>No.</th>
        <th>Ọnwa (Month)</th>
        <th>Gregorian span (this cycle)</th>
        <th>Traditional hint</th>
        <th>Start market day</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($igboYear['months'] as $monthNum => $monthData): ?>
        <?php
          $meta = $monthData['meta'];
          $def  = $monthDefs[$monthNum] ?? [
            'name'      => $meta['name'],
            'alt_name'  => $meta['alt_name'] ?? null,
            'greg_hint' => $meta['greg_hint'] ?? '',
          ];
          $name       = $def['name'];
          $altName    = $def['alt_name'] ?? null;
          $span       = $meta['greg_span'];            // e.g. "Feb Thu 20 – Mar Wed 19"
          $hint       = $def['greg_hint'] ?? '';
          $startW     = $meta['start_weekday_name'] ?? '';
          $displayName = $altName
            ? $name . ' / ' . $altName
            : $name;
        ?>
        <tr>
          <td><?= (int)$monthNum ?></td>
          <td><?= h($displayName) ?></td>
          <td><?= h($span) ?></td>
          <td><?= h($hint) ?></td>
          <td><?= h($startW) ?></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <p>
    Each month below is drawn as a four-column grid of the market days:
    <strong>Eke</strong>, <strong>Orie</strong>, <strong>Afọ</strong>, and <strong>Nkwọ</strong>.
    The first day of each month enters under the actual market day for that month, which means
    some months will begin under Orie or Afọ or Nkwọ instead of always starting from Eke.
    Because of this alignment, a month may use seven or eight rows to accommodate all the days.
  </p>

  <div class="igbo-calendar-months">
    <?php foreach ($igboYear['months'] as $monthNum => $monthData): ?>
      <?php
        $meta = $monthData['meta'];
        $rows = $monthData['rows'];

        $def = $monthDefs[$monthNum] ?? [
          'name'      => $meta['name'],
          'alt_name'  => $meta['alt_name'] ?? null,
          'greg_hint' => $meta['greg_hint'] ?? '',
        ];
        $name        = $def['name'];
        $altName     = $def['alt_name'] ?? null;
        $displayName = $altName
          ? $name . ' / ' . $altName
          : $name;

        $span   = $meta['greg_span'];       // "Feb Thu 20 – Mar Wed 19"
        $hint   = $def['greg_hint'];        // "February–March"
        $startW = $meta['start_weekday_name'];
      ?>
      <section class="igbo-month">
        <h2><?= h($displayName) ?></h2>
        <p class="month-span">
          <?= h($span) ?><br>
          <em><?= h($hint) ?></em>
        </p>
        <p class="igbo-month-subtitle">
          Month starts on: <strong><?= h($startW) ?></strong>
        </p>
        <table>
          <thead>
            <tr>
              <?php foreach ($weekdayNames as $w): ?>
                <th><?= h($w) ?></th>
              <?php endforeach; ?>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($rows as $row): ?>
              <tr>
                <?php foreach ($row as $cell): ?>
                  <?php if ($cell === null): ?>
                    <td>&nbsp;</td>
                  <?php else: ?>
                    <?php
                      $isTodayCell = false;
                      if ($igboToday !== null && !$cell['is_festival']) {
                        $isTodayCell =
                          ($cell['day_of_year'] === $igboToday['day_of_year']) &&
                          ($igboToday['is_festival'] === false);
                      }
                      $moonSymbol = $cell['lunar_symbol'] ?? '';
                    ?>
                    <td class="<?= $isTodayCell ? 'igbo-today' : '' ?>">
                      <span class="igbo-day-num">
                        <?= (int)$cell['day_in_month'] ?>
                      </span>
                      <?php if ($moonSymbol !== ''): ?>
                        <span class="igbo-moon-symbol">
                          <?= h($moonSymbol) ?>
                        </span>
                      <?php endif; ?>
                      <span class="igbo-lunar">
                        <?= h($cell['lunar_stage']) ?>
                      </span>
                      <span class="igbo-greg">
                        <?= h($cell['gregorian_date']->format('Y-m-d')) ?>
                      </span>
                    </td>
                  <?php endif; ?>
                <?php endforeach; ?>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </section>
    <?php endforeach; ?>
  </div>
</div>
<script>
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', function () {
      navigator.serviceWorker.register('/service-worker-igbo-calendar.js')
        .catch(function (err) {
          console.error('Service worker registration failed:', err);
        });
    });
  }
</script>
</body>
</html>