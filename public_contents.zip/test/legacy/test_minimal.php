<?php
   echo "Before initialize<br>";
   require_once('../private/assets/initialize.php');
   echo "After initialize<br>";
   ?>
   <h1>Minimal Page Works</h1>
   
