<?php 
// project-root/public/test_subjects.php

require_once('../private/assets/initialize.php'); 
include_once(dirname(__DIR__) . '/private/shared/public_header.php'); 
?>

<h2>Subjects Test Page</h2>
<p>If you see this, the subjects template is working with header and footer.</p>

<?php include_once(dirname(__DIR__) . '/private/shared/public_footer.php'); ?>
