<?php 
// project-root/public/test_contributors.php

require_once('../private/assets/initialize.php'); 
include_once(dirname(__DIR__) . '/private/shared/public_header.php'); 
?>

<h2>Contributors Test Page</h2>
<p>If you see this, the contributors template is working with header and footer.</p>

<?php include_once(dirname(__DIR__) . '/private/shared/public_footer.php'); ?>
