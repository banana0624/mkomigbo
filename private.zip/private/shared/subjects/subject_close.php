<?php
// Universal subject wrapper (CLOSE). Pairs with subject_open.php
?>
  </article>
</section>
