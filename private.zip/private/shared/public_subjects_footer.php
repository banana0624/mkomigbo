<?php
// project-root/private/shared/subjects/public_subjects_footer.php
?>
    <footer class="subjects-footer" style="text-align:center; padding:1.5rem 1rem 2.5rem; color:#777; font-size:.85rem;">
  &copy; <?= date('Y'); ?> Mkomigbo. All rights reserved.
</footer>
</body>
</html>
