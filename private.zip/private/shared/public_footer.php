<?php
// project-root/private/shared/subjects/public_subjects_footer.php
// Keep it simple: delegate to the shared footer so styles/scripts stay consistent.
require_once dirname(__DIR__) . '/footer.php';
