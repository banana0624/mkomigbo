<?php
declare(strict_types=1);

/**
 * private/shared/subjects/subjects_footer.php
 */
?>
</main>
<footer class="subjects-footer">
  <div class="container">
    <p>&copy; <?php echo date('Y'); ?> Mkomigbo</p>
  </div>
</footer>
<?php
require_once __DIR__ . '/../footer.php';
?>
