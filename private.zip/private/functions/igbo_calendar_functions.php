<?php
declare(strict_types=1);

/**
 * project-root/private/functions/igbo_calendar_functions.php
 *
 * Core helpers for the Igbo 13-month calendar (Ọnwa system).
 *
 * Model (version 2):
 * - 13 months (Ọnwa), each with 28 counted days → 364 days.
 * - 4-day market week: Eke, Orie, Afọ, Nkwọ.
 * - Each month can BEGIN on any of the four market days
 *   (Eke/Orie/Afọ/Nkwọ), so day 1 does not always sit under Eke.
 * - Month grids therefore use leading blanks and can run to 7 or 8 rows.
 *
 * Lunar handling:
 * - We use a 28-day approximate lunar cycle per month:
 *   New → waxing → full → waning → dark.
 * - Each day gets a textual stage and a visual moon symbol (emoji).
 *
 * NOTE:
 * - This is still a mathematical model. We are NOT yet doing full
 *   astronomical lunar calculations. When you provide more precise
 *   traditional rules, we can refine:
 *   - month start days,
 *   - intercalary day handling,
 *   - and any variable-length months if needed.
 */

/**
 * Day names in the Igbo 4-day week.
 *
 * Index: 0 => Eke, 1 => Orie, 2 => Afọ, 3 => Nkwọ.
 */
function igbo_weekday_names(): array {
  return ['Eke', 'Orie', 'Afọ', 'Nkwọ'];
}

/**
 * Month definitions: 1..13.
 *
 * Each month has:
 * - name       : primary name.
 * - alt_name   : optional dialect variant (or null).
 * - greg_hint  : rough Gregorian alignment.
 * - description: cultural notes (for future use in tooltips / details).
 */
function igbo_month_definitions(): array {
  return [
    1  => [
      'name'        => 'Ọnwa Mbụ',
      'alt_name'    => null,
      'greg_hint'   => 'February–March (Igbo New Year)',
      'description' => 'First month of the Igbo year, beginning with the new moon around the third week of February. In Nri tradition, the Igu Aro year-counting festival marks the new cycle; the recorded Nri calendar has passed 1000 years.'
    ],
    2  => [
      'name'        => 'Ọnwa Abụọ',
      'alt_name'    => null,
      'greg_hint'   => 'March–April',
      'description' => 'Month dedicated to cleaning, preparing homesteads, and beginning major farming work.'
    ],
    3  => [
      'name'        => 'Ọnwa Ife Eke',
      'alt_name'    => null,
      'greg_hint'   => 'April–May',
      'description' => 'Often called Ugani – a period of fasting, hunger and discipline. Communities may hold wrestling contests as a test of strength and a way of finding one’s Ikenga through struggle.'
    ],
    4  => [
      'name'        => 'Ọnwa Anọ',
      'alt_name'    => null,
      'greg_hint'   => 'May–June',
      'description' => 'Time when seed yams are planted. In many communities this is the month of the Ekeleke dance festival, emphasizing hope, endurance and trust in God through hardship.'
    ],
    5  => [
      'name'        => 'Ọnwa Agwụ',
      'alt_name'    => null,
      'greg_hint'   => 'June–July',
      'description' => 'Month of Agwụ. Adult masquerades (mmanwụ) appear and the Alusi Agwụ is specially venerated by Dibia. In many traditions this is the spiritual “start” of the ritual year.'
    ],
    6  => [
      'name'        => 'Ọnwa Ifejiọkụ',
      'alt_name'    => null,
      'greg_hint'   => 'July–August',
      'description' => 'Month of the yam deity Ifejiọkụ and Njoku Ji. Yam rituals and preparations for the New Yam festival are central.'
    ],
    7  => [
      'name'        => 'Ọnwa Alọm Chi',
      'alt_name'    => null,
      'greg_hint'   => 'August–early September',
      'description' => 'Yam harvest month and a deep period of prayer, reflection and honouring motherhood. The Alọm Chi shrine connects women to their ancestors and “first mother”; this month emphasises women, mothers and future children.'
    ],
    8  => [
      'name'        => 'Ọnwa Ilọ Mmụọ',
      'alt_name'    => 'Ọnwa Agbara',
      'greg_hint'   => 'Late September (Ọnwa Asatọ – Eighth Month)',
      'description' => 'Also known as Ọnwa Asatọ in some areas. A time of returning of spirits (mmụọ/agbara); communities may hold festivals marking spiritual presence and visitation.'
    ],
    9  => [
      'name'        => 'Ọnwa Ana',
      'alt_name'    => 'Ọnwa Ala',
      'greg_hint'   => 'October',
      'description' => 'Month of Ana/Ala, the earth goddess. Rituals and taboos concerning land, morality and community order are emphasized.'
    ],
    10 => [
      'name'        => 'Ọnwa Okike',
      'alt_name'    => null,
      'greg_hint'   => 'Early November',
      'description' => 'Month when Okike rites take place. A period that recalls creation, order and the laws that hold the world together.'
    ],
    11 => [
      'name'        => 'Ọnwa Ajana',
      'alt_name'    => 'Ọnwa Ajala',
      'greg_hint'   => 'Late November',
      'description' => 'Another phase of Okike-related rituals and community observances, preparing the ground for closing rites of the year.'
    ],
    12 => [
      'name'        => 'Ọnwa Ede Ajana',
      'alt_name'    => 'Ọnwa Ede Ajala',
      'greg_hint'   => 'Late November–December',
      'description' => 'Rituals begin to wind down. Communities move towards the end of the sacred cycle, completing obligations and offerings.'
    ],
    13 => [
      'name'        => 'Ọnwa Ụzọ Alụsị',
      'alt_name'    => 'Ọnwa Ụzọ Arushi',
      'greg_hint'   => 'January–early February',
      'description' => 'The “road of the deities” month, leading out of the old year and into the transitional period before the new moon of the next Ọnwa Mbụ appears.'
    ],
  ];
}

/**
 * Simple lunar stage label for a 28-day cycle.
 *
 * We approximate:
 *  1      → New Moon
 *  2–6    → Waxing crescent
 *  7      → First quarter
 *  8–13   → Waxing gibbous
 *  14     → Full moon
 *  15–21  → Waning gibbous
 *  22     → Last quarter
 *  23–27  → Waning crescent
 *  28     → Dark / Old moon
 */
function igbo_lunar_stage_for_day(int $dayInMonth): string {
  if ($dayInMonth <= 1) {
    return 'New moon';
  } elseif ($dayInMonth <= 6) {
    return 'Waxing crescent';
  } elseif ($dayInMonth === 7) {
    return 'First quarter';
  } elseif ($dayInMonth <= 13) {
    return 'Waxing gibbous';
  } elseif ($dayInMonth === 14) {
    return 'Full moon';
  } elseif ($dayInMonth <= 21) {
    return 'Waning gibbous';
  } elseif ($dayInMonth === 22) {
    return 'Last quarter';
  } elseif ($dayInMonth <= 27) {
    return 'Waning crescent';
  } else { // 28
    return 'Dark / Old moon';
  }
}

/**
 * Moon icon (emoji) for visual display, based on day in month.
 * This gives a visible, progressive moon shape across the month.
 */
function igbo_lunar_symbol_for_day(int $dayInMonth): string {
  if ($dayInMonth <= 1) {
    return '🌑'; // New
  } elseif ($dayInMonth <= 3) {
    return '🌒'; // Waxing crescent
  } elseif ($dayInMonth <= 7) {
    return '🌓'; // First quarter-ish
  } elseif ($dayInMonth <= 10) {
    return '🌔'; // Waxing gibbous
  } elseif ($dayInMonth <= 17) {
    return '🌕'; // Full-ish
  } elseif ($dayInMonth <= 20) {
    return '🌖'; // Waning gibbous
  } elseif ($dayInMonth <= 23) {
    return '🌗'; // Last quarter-ish
  } elseif ($dayInMonth <= 27) {
    return '🌘'; // Waning crescent
  } else {
    return '🌑'; // Dark / Old moon
  }
}

/**
 * Format Gregorian span for a month:
 * e.g. "Feb Thu 20 – Mar Wed 19"
 */
function igbo_month_gregorian_span_label(DateTimeImmutable $start): string {
  $end = $start->modify('+27 days');

  $startLabel = $start->format('M D j'); // e.g. Feb Thu 20
  $endLabel   = $end->format('M D j');   // e.g. Mar Wed 19

  return "{$startLabel} – {$endLabel}";
}

/**
 * Decide the weekday index of DAY 1 for a given month.
 *
 * For now, we use a simple rotating pattern:
 *   Month 1 → Eke (0)
 *   Month 2 → Orie (1)
 *   Month 3 → Afọ (2)
 *   Month 4 → Nkwọ (3)
 *   Month 5 → Eke (0) again, etc.
 *
 * This ensures that different months can begin under different
 * market-day columns, instead of always starting under Eke.
 *
 * Later, when you provide full rules (e.g. based on exact new moons),
 * we can replace this with your precise tradition.
 */
function igbo_month_start_weekday_index(int $monthNum): int {
  return ($monthNum - 1) % 4; // 0..3
}

/**
 * Convert a Gregorian date into an Igbo date within a given Igbo year.
 *
 * @param DateTimeInterface $gregDate       Gregorian date.
 * @param DateTimeInterface $igboYearStart  Gregorian date that is
 *                                          Igbo day 1, month 1.
 * @param string|null       $yearLabel
 *
 * @return array|null
 *   [
 *     'year_label'    => string|null,
 *     'day_of_year'   => int,           // 1..364 or >364 for festival
 *     'month'         => int|null,      // 1..13, null if festival
 *     'day_in_month'  => int|null,      // 1..28, null if festival
 *     'weekday_index' => int,
 *     'weekday_name'  => string,
 *     'lunar_stage'   => string|null,
 *     'lunar_symbol'  => string|null,
 *     'is_festival'   => bool,
 *   ]
 */
function igbo_from_gregorian(
  DateTimeInterface $gregDate,
  DateTimeInterface $igboYearStart,
  ?string $yearLabel = null
): ?array {
  $start = (new DateTimeImmutable($igboYearStart->format('Y-m-d')))->setTime(0, 0, 0);
  $date  = (new DateTimeImmutable($gregDate->format('Y-m-d')))->setTime(0, 0, 0);

  if ($date < $start) {
    return null;
  }

  $diff   = $start->diff($date);
  $offset = (int)$diff->days; // 0-based across year

  if ($offset >= 364) {
    // Festival/intercalary region.
    $weekdayIndex = $offset % 4;
    $weekdayName  = igbo_weekday_names()[$weekdayIndex];

    return [
      'year_label'    => $yearLabel,
      'day_of_year'   => 364 + ($offset - 364) + 1, // e.g. 365, 366, ...
      'month'         => null,
      'day_in_month'  => null,
      'weekday_index' => $weekdayIndex,
      'weekday_name'  => $weekdayName,
      'lunar_stage'   => null,
      'lunar_symbol'  => null,
      'is_festival'   => true,
    ];
  }

  // Inside the 13×28 grid.
  $dayOfYear   = $offset + 1;          // 1..364
  $monthIndex  = intdiv($offset, 28);  // 0..12
  $dayInMonth  = ($offset % 28) + 1;   // 1..28
  $monthNumber = $monthIndex + 1;      // 1..13

  $monthStartWeekday = igbo_month_start_weekday_index($monthNumber);
  $weekdayIndex      = ($monthStartWeekday + $dayInMonth - 1) % 4;
  $weekdayName       = igbo_weekday_names()[$weekdayIndex];

  return [
    'year_label'    => $yearLabel,
    'day_of_year'   => $dayOfYear,
    'month'         => $monthNumber,
    'day_in_month'  => $dayInMonth,
    'weekday_index' => $weekdayIndex,
    'weekday_name'  => $weekdayName,
    'lunar_stage'   => igbo_lunar_stage_for_day($dayInMonth),
    'lunar_symbol'  => igbo_lunar_symbol_for_day($dayInMonth),
    'is_festival'   => false,
  ];
}

/**
 * Generate the full Igbo year structure.
 *
 * Return shape:
 * [
 *   'year_label' => ...,
 *   'start_date' => DateTimeImmutable,
 *   'months'     => [
 *     1 => [
 *       'meta' => [
 *         'index'               => int,
 *         'name'                => string,
 *         'alt_name'            => string|null,
 *         'greg_hint'           => string,
 *         'description'         => string,
 *         'start_date'          => DateTimeImmutable,
 *         'end_date'            => DateTimeImmutable,
 *         'greg_span'           => string,
 *         'start_weekday_index' => int,
 *         'start_weekday_name'  => string,
 *       ],
 *       'rows' => [
 *         // Each row: array of 4 cells (Eke, Orie, Afọ, Nkwọ),
 *         // null for blank cells, or an array for real days:
 *         // [
 *         //   'gregorian_date' => DateTimeImmutable,
 *         //   'day_of_year'    => int,
 *         //   'month'          => int,
 *         //   'day_in_month'   => int,
 *         //   'weekday_index'  => int,
 *         //   'weekday_name'   => string,
 *         //   'lunar_stage'    => string,
 *         //   'lunar_symbol'   => string,
 *         // ]
 *       ],
 *     ],
 *     ...
 *   ],
 * ]
 */
function igbo_year_grid(DateTimeInterface $igboYearStart, ?string $yearLabel = null): array {
  $start        = (new DateTimeImmutable($igboYearStart->format('Y-m-d')))->setTime(0, 0, 0);
  $monthDefs    = igbo_month_definitions();
  $weekdayNames = igbo_weekday_names();

  $months = [];

  for ($m = 1; $m <= 13; $m++) {
    $monthStartOffset = 28 * ($m - 1);               // 0-based offset from year start
    $monthStart       = $start->modify("+{$monthStartOffset} days");
    $monthEnd         = $monthStart->modify('+27 days');
    $startWeekdayIdx  = igbo_month_start_weekday_index($m);

    $def = $monthDefs[$m] ?? [
      'name'        => "Month {$m}",
      'alt_name'    => null,
      'greg_hint'   => '',
      'description' => '',
    ];

    $months[$m] = [
      'meta' => [
        'index'               => $m,
        'name'                => $def['name'],
        'alt_name'            => $def['alt_name'],
        'greg_hint'           => $def['greg_hint'],
        'description'         => $def['description'],
        'start_date'          => $monthStart,
        'end_date'            => $monthEnd,
        'greg_span'           => igbo_month_gregorian_span_label($monthStart),
        'start_weekday_index' => $startWeekdayIdx,
        'start_weekday_name'  => $weekdayNames[$startWeekdayIdx],
      ],
      'rows' => [],
    ];

    $daysInMonth = 28; // still 28 counted days for now

    // Month grid: 4 columns (market days), up to 8 rows.
    $offset   = $startWeekdayIdx;          // leading blanks
    $numCells = $offset + $daysInMonth;    // total cells needed
    $numRows  = (int)ceil($numCells / 4);  // 7 or 8 rows

    $dayCounter = 0;

    for ($row = 0; $row < $numRows; $row++) {
      $rowCells = [];

      for ($col = 0; $col < 4; $col++) {
        $cellIndex = $row * 4 + $col;

        if ($cellIndex < $offset || $dayCounter >= $daysInMonth) {
          // Blank cell (no day here)
          $rowCells[] = null;
          continue;
        }

        $dayCounter++;
        $dayInMonth   = $dayCounter; // 1..28
        $globalOffset = $monthStartOffset + ($dayInMonth - 1);
        $dayOfYear    = $globalOffset + 1;

        $weekdayIndex = ($startWeekdayIdx + $dayInMonth - 1) % 4;
        $weekdayName  = $weekdayNames[$weekdayIndex];
        $currentDate  = $monthStart->modify('+' . ($dayInMonth - 1) . ' days');

        $rowCells[] = [
          'gregorian_date' => $currentDate,
          'year_label'     => $yearLabel,
          'day_of_year'    => $dayOfYear,
          'month'          => $m,
          'day_in_month'   => $dayInMonth,
          'weekday_index'  => $weekdayIndex,
          'weekday_name'   => $weekdayName,
          'lunar_stage'    => igbo_lunar_stage_for_day($dayInMonth),
          'lunar_symbol'   => igbo_lunar_symbol_for_day($dayInMonth),
          'is_festival'    => false,
        ];
      }

      $months[$m]['rows'][] = $rowCells;
    }
  }

  return [
    'year_label' => $yearLabel,
    'start_date' => $start,
    'months'     => $months,
  ];
}