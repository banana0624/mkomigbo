<?php
// project-root/private/config/env.php
    return [
      'DB_HOST' => 'localhost',
      'DB_NAME' => 'mkomigbo_prod',
      'DB_USER' => 'dbuser',
      'DB_PASS' => 'strongpassword',
      'APP_ENV' => 'production',
      'APP_URL' => 'https://www.mkomigbo.com',
    ];
    